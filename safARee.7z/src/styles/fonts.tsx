export const fonts = {
  bold: 'OpenSans-Bold',
  extraBold: 'OpenSans-ExtraBold',
  medium: 'OpenSans-Medium',
  regular: 'OpenSans-Regular',
  small: 'OpenSans-Regular',
};
