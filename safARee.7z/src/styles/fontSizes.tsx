export const fontSizes = {
  regular: 15,
  extraBig: 22,
  big: 16,
  semiExtraBig: 18,
  small: 12,
};
